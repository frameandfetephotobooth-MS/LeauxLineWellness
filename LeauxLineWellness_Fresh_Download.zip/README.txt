LEAUX LINE WELLNESS WEBSITE
1. Extract this ZIP.
2. Open LeauxLineWellness_Website_Ready.html in Chrome or Edge to preview.
3. The images are embedded in the HTML file; no separate assets folder is needed.
4. For Wix, use the hosted page/embed approach or rebuild the sections natively.
